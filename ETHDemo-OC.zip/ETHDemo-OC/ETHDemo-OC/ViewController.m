//
//  ViewController.m
//  ETHDemo-OC
//
//  Created by Alan on 2019/5/22.
//  Copyright © 2019 Alan. All rights reserved.
//

#import "ViewController.h"
#import "NSData+MyChange.h"
#import "NSString+MyChange.h"
#include "ccMemory.h"
#include "aes.h"
#include "sha3.h"
#include "secp256k1.h"
#import "Address.h"
#import "SecureData.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    /**
     私钥：0xeef393f053a9e3a05a7a04deb5d49862ba9c043a0cb0d4a931817be6bd933435
     地址：0x4ccc6fab6f01ada8c155ae8ec12e5487aee5a972
     Encoding Address 地址：0x4CCC6FaB6f01ADa8C155aE8EC12E5487aeE5a972
     ---------------------
     */
    
    /**
     18e14a7b6a307f426a94f8114701e7c8e774e7f9a47e2c2035db29a206321725
     
     第二步：公钥 (public key)
     
     　　1. 采用椭圆曲线数字签名算法ECDSA-secp256k1将私钥（32字节）映射成公钥（65字节）（前缀04+X公钥+Y公钥）：
     
     　　04
     　　50863ad64a87ae8a2fe83c1af1a8403cb53f53e486d8511dad8a04887e5b2352
     　　2cd470243453a299fa9e77237716103abc11a1df38855ed6f2ee187e9c582ba6
     
     2. 拿公钥（非压缩公钥）来hash，计算公钥的 Keccak-256 哈希值（32bytes）：
     
     　　fc12ad814631ba689f7abe671016f75c54c607f082ae6b0881fac0abeda21781
     
     
     3. 取上一步结果取后20bytes即以太坊地址：
     
     　　1016f75c54c607f082ae6b0881fac0abeda21781
     
     第三步：地址 (address)
     
     　　0x1016f75c54c607f082ae6b0881fac0abeda21781
     */
    
    //18e14a7b6a307f426a94f8114701e7c8e774e7f9a47e2c2035db29a206321725
    //0x3e9003153d9a39d3f57b126b0c38513d5e289c3e
    
    //eef393f053a9e3a05a7a04deb5d49862ba9c043a0cb0d4a931817be6bd933435
    //0x4CCC6FaB6f01ADa8C155aE8EC12E5487aeE5a972
    
    NSString *private = @"eef393f053a9e3a05a7a04deb5d49862ba9c043a0cb0d4a931817be6bd933435";
    NSData *privateData = private.my_dataFromHexString;
    
    //获取公钥
    NSMutableData *publicKeyData = [[NSMutableData alloc] initWithLength:65];
    ecdsa_get_public_key65(&secp256k1, privateData.bytes, publicKeyData.mutableBytes);
    
    //截掉第一个字节04
    NSData *subPublicKeyData = [publicKeyData subdataWithRange:NSMakeRange(1, publicKeyData.length - 1)];
    
    //SHA3  KECCAK-256 哈希 单向散列函数变成了32字节
    NSMutableData *secureData = [[NSMutableData alloc] initWithLength:256 / 8];
    SHA3_CTX context;
    keccak_256_Init(&context);
    keccak_Update(&context, subPublicKeyData.bytes, (size_t)subPublicKeyData.length);
    keccak_Final(&context, secureData.mutableBytes);
    CC_XZEROMEM(&context, sizeof(SHA3_CTX));
    
    //删除前24个字符/ 12个字节 并拼接0x
    NSData *addressData = [secureData subdataWithRange:NSMakeRange(12, secureData.length - 12)];
    
    //核查地址中字母大小写
    Address *addres = [Address addressWithData:addressData];
    
    NSLog(@"地址：%@",addres.checksumAddress);
    
//    NSURL *url = [[NSURL alloc] initWithString:@""];
//    NSURLSessionConfiguration *sessionConfiguration = [NSURLSessionConfiguration defaultSessionConfiguration];
//
//    AFHTTPSessionManager *manager = [[AFHTTPSessionManager alloc] initWithBaseURL:url sessionConfiguration:sessionConfiguration];
//
//    manager.securityPolicy.allowInvalidCertificates = NO;
//    [manager.reachabilityManager startMonitoring];
//    //发送json数据
//    //manager.requestSerializer = [AFHTTPRequestSerializer serializer];
//    manager.requestSerializer = [AFJSONRequestSerializer serializer];
//
//    //响应json数据
//    manager.responseSerializer  = [AFJSONResponseSerializer serializer];
//
//    NSMutableSet *acceptableContentTypes = [NSMutableSet setWithSet:manager.responseSerializer.acceptableContentTypes];
//    [acceptableContentTypes addObject:@"text/plain"];
//    [acceptableContentTypes addObject:@"text/html"];
//    manager.responseSerializer.acceptableContentTypes = acceptableContentTypes;
//
//    manager.requestSerializer.timeoutInterval = 30.0;
//
//
//    NSString *checksunAddress = @"0x742d35cc6634c0532925a3b844bc454e4438f44e";
//
//    [manager GET:[NSString stringWithFormat:@"https://api.etherscan.io/api?module=account&action=balance&address=%@&tag=latest&apikey=42SXVSCEDXMFIRKXIFWG1GWYDY7XKZT7NVn",checksunAddress] parameters:@{} progress:^(NSProgress * _Nonnull uploadProgress) {
//    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
//
//        if (responseObject) {
//
//            NSString *result = responseObject[@"result"];
//
//            CGFloat num = [result doubleValue];
//
//            num = num/1000000000000000000.0;
//
//            NSString *numString = [NSString stringWithFormat:@"%f",num];
//        }
//    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
//
//    }];
}


@end
