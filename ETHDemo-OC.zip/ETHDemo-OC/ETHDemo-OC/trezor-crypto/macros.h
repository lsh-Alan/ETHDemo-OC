#ifndef __MACROS_H__
#define __MACROS_H__

#define MEMSET_BZERO(p,l)	memset((p), 0, (l))

#endif
